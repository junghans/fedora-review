/* minimal config to run SHANCHEN testcase */
#define LB_GPU
#define SHANCHEN
#define EXTERNAL_FORCES
#define PARTIAL_PERIODIC

