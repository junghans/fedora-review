/* left over features that were not compiled with: */
/* myconfig-maxset.h or myconfig-restcompile1.h */
#define BOND_CONSTRAINT
#define VIRTUAL_SITES_COM
/* using ADRESS causes several tests to fail */
/* #define ADRESS */
