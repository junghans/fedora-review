/* minimal set of config for the tunable slip testcase */
#define DPD
#define TRANS_DPD
#define INTER_DPD
#define DPD_MASS_RED
#define TUNABLE_SLIP
#define EXTERNAL_FORCES
#define CONSTRAINTS
#define LENNARD_JONES
