.. Extensible Simulation Package for Soft Matter Research documentation master file, created by
   sphinx-quickstart on Thu Oct  6 11:27:00 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to the ESPResSo documentation!
======================================

Contents:

.. toctree::
    :maxdepth: 2

    Userguide <ug>

espressomd package
==================

.. toctree::
    :maxdepth: 2

    modules.rst

.. automodule:: espressomd
    :members: 
    :private-members:

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
