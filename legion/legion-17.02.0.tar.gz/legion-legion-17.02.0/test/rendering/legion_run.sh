#!/bin/bash
./rendering -ll:cpu 8 -ll:csize 8192 -ll:gsize 0 -ll:lmbsize 8192 -c

